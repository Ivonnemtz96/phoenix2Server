<!-- All JavaScript files=================================== -->
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/js/bootstrap.bundle.min.js"></script>
<!-- Plugins for this template -->
<script src="/assets/js/modernizr.custom.js"></script>
<script src="/assets/js/jquery.dlmenu.js"></script>
<script src="/assets/js/jquery-plugin-collection.js"></script>
<!-- Custom script for this template -->
<script src="/assets/js/script.js"></script>
