<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Contacto';
$contacto = 'active';

include('includes/head.php');
include_once("php/msg.php");
?>

<body>
    <div class="page-wrapper">

    <?php 
        include('includes/preloader.php');
        include('includes/header.php');
        include('modules/contact.php');
        include('includes/footer.php');
        include('includes/scripts.php');
    ?>

    </div>
    

</body>

</html>