<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Equipo';
$equipo = 'active';

include('includes/head.php');
?>

<body>
    <div class="page-wrapper">

    <?php 
        include('includes/preloader.php');
        include('includes/header.php');
        include('modules/equipo.php');
        include('includes/footer.php');
        include('includes/scripts.php');
    ?>

    </div>
    

</body>

</html>